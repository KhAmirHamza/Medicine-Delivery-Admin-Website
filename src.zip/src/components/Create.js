import React from 'react';

const Create = () => {
    return (
        <div>
            <p>Create New Blog</p>
        </div>
    );
};

export default Create;