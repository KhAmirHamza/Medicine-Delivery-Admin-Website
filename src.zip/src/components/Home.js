import {React,useState, useEffect} from 'react';
import Blog from './Blog';

const Home = () => {

    const [blogs, setBlogs] = useState([
        {name: "people1", age: 21, address: "Dhaka", id: 1},
        {name: "people2", age: 25, address: "Nagarpur", id: 2},
        {name: "people2", age: 27, address: "Tangail", id: 3}
    ])

    const handleDelete = (id)=>{
        setBlogs(blogs.filter(blog=>blog.id!==id));
    }

    const [name, setName] = useState("Khandakar Amir Hamza")

    useEffect(()=>{
        console.log("use Effect run");
    },[name])
    

    return (
        <div className="home">
            <Blog blogs={blogs} handleDelete={handleDelete}/>
            <h3>{name}</h3>
            <button onClick={()=>{setName("Hriday")}}>Change Name</button>
        </div>
    );
};

export default Home;