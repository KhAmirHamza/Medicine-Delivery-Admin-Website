import React, { useState } from 'react';
import { Button, Form, FormGroup, Label, Input, FormText,Spinner } from 'reactstrap';
import axios from 'axios'

const AddMedicine2 = () => {

    const {imageFile, setImageFile} = useState("");
    const {medicineImage, setMedicineImage} = useState(null);
    const {progressVisibility, setProgressVisibility} = useState("invisible");
    const {medicine, setMedicine} = useState({name: "",image_url: "", price : "", brand: "", features: "", indication: "",description: ""});

const medicineData = {name: "",image_url: medicineImage, price : "", brand: "", features: "", indication: "",description: ""};

    const onTextChangeHandler = (event)=>{
        var component = event.target.name;
        var value = event.target.value
      
        var medicineField = ["name", "image_url", "price", "brand", "features", "indication", "description"];
        var medicineValue = [];
        
        for (let index = 0; index < medicineField.length; index++) {
          
          medicineValue[0] = this.medicineData.name;
          medicineValue[1]  = this.medicineData.image_url;
          medicineValue[2]  = this.medicineData.price;
          medicineValue[3]  = this.medicineData.brand;
          medicineValue[4]  = this.medicineData.features;
          medicineValue[5]  = this.medicineData.indication;
          medicineValue[6]  = this.medicineData.description;
    
          const element = medicineField[index];
          if (component===element) {
            medicineValue[index] = value;
    
            this.medicineData = {
              name: medicineValue[0],
              image_url: medicineValue[1],
               price : medicineValue[2],
                brand: medicineValue[3],
                 features: medicineValue[4], 
                 indication: medicineValue[5],
                 description: medicineValue[6]};
          }
        }
    
       //console.log(this.state.medicine);
       //console.log(this.medicineData);
        //console.log(document.getElementsByName(component).value);
       // alert(this.state.medicine);
      }
    
      const onSubmitListener = (event)=> {
        //setProgressVisibility("visible");
        console.log(medicineData);
        const formData = new FormData();
        //formData.append("uploadImage", imageFile, imageFile.name);
        axios.post("https://hellometbd.com/uploadImageToGenarateUrl/", formData)
          .then(response => {
            console.log(response);
      
            var medicineValue = [];
            medicineValue[0] = this.medicineData.name;
            medicineValue[1]  = response.data.url;
            medicineValue[2]  = this.medicineData.price;
            medicineValue[3]  = this.medicineData.brand;
            medicineValue[4]  = this.medicineData.features;
            medicineValue[5]  = this.medicineData.indication;
            medicineValue[6]  = this.medicineData.description;
            this.medicineData = {
              name: medicineValue[0],
              image_url: medicineValue[1],
               price : medicineValue[2],
                brand: medicineValue[3],
                 features: medicineValue[4], 
                 indication: medicineValue[5],
                 description: medicineValue[6]
                };
            
            //console.log(this.state.medicine);
            axios.post("https://hellomet-health-98.herokuapp.com/medicine/", {meta_data: this.medicineData})
            .then(res =>{
              console.log(response);
            this.setState({ progressVisibility: "invisible"});
            alert("Medicine Upload Successfully.")
            })
          })
      }
    
      const onImageChangeHandler = (event)=> {
        setImageFile(event.target.files[0]);
        const reader = new FileReader();
        reader.onload = () => {
          if (reader.readyState === 2) {
             setMedicineImage(reader.result)
          }
        }
        reader.readAsDataURL(event.target.files[0]);
      }
    
      const handleSubmit = (event)=> {
    
        event.preventDefault();
        alert(
          `Selected file - ${this.fileInput.current.files[0].name}`
        );
      }






    return (
        <div>
            <Form >
            <Form.Group controlId="formBasicImage">

              <Form.Control className={["mx-auto", "mt-5", "border border-primary"]}
                style={{ width: '700px' }} type="file" onChange={(e)=>onImageChangeHandler(e)} />
              {/* <image className={["mx-auto", "mt-1"]} style={{ height: "350px", width: "350px" }}
                src={medicineImage} /> */}

            </Form.Group>

            <Form.Group controlId="name">
              <Form.Control
                as="textarea" rows={1}
                name= "name"
                className={["mx-auto", "mt-1"]} style={{ width: '700px' }}
               // onChange={(e)=>onTextChangeHandler(e)}
                type="text" placeholder="Medicine Name" />
            </Form.Group>

            <Form.Group controlId="price">
              <Form.Control
                as="textarea" rows={1}
                name= "price"
                className="mx-auto" style={{ width: '700px' }}
               // onChange={(e)=>onTextChangeHandler(e)}
                type="number" placeholder="Medicine Price" />
            </Form.Group>


            <Form.Group controlId="brand">
              <Form.Control
                as="textarea" rows={1}
                name= "brand"
                className="mx-auto"
               // onChange={(e)=>onTextChangeHandler(e)}
                style={{ width: '700px' }}
                type="text" placeholder="Medicine Brand" />
            </Form.Group>

            <Form.Group controlId="features">
              <Form.Control
                as="textarea" rows={2}
                name= "features"
                className={["mx-auto", "mt-0"]}
               // onChange={(e)=>onTextChangeHandler(e)}
                style={{ width: '700px' }}
                type="text" placeholder="Medicine Feature" />
            </Form.Group>



            <Form.Group controlId="indication">
              <Form.Control className={["mx-auto", "mt-0"]}
                as="textarea" rows={3}
                name= "indication"
                style={{ width: '700px' }}
                //onChange={(e)=>onTextChangeHandler(e)}
                type="text" placeholder="Medicine Indication" />
            </Form.Group>

            <Form.Group controlId="description">
              <Form.Control
                as="textarea" rows={5}
                name= "description"
                className="mx-auto"
                style={{ width: '700px' }}
                //onChange={(e)=>onTextChangeHandler(e)}
                type="text" placeholder="Medicine Description"
              />

            </Form.Group>


          </Form>

          <Spinner className={["mb-3", "mr-3", progressVisibility]} animation="grow" role="status">
          <span className={["sr-only"]}>Loading...</span>
        </Spinner>
        <Button
          className={"mb-5"}
          variant="primary"
          type="submit" style={{ width: '500px' }}
         // onClick={onSubmitListener()}
        >
          Add Medicine
  </Button>

        </div>
    );
};

export default AddMedicine2;