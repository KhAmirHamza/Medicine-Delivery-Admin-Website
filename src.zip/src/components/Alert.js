import React, { useRef, useState } from 'react';
import { Button, Overlay, Popover } from 'react-bootstrap';

const CustomAlert = (target, show) => {
    //const [show, setShow] = useState(true);
   // const [target, setTarget] = useState(null);
   // const ref = useRef(null);


        
       //<div ref={ref}>
    // alert("yes")

      <Overlay
        show={true}
        target={target}
        placement="bottom"
        //container={ref.current}
       // containerPadding={20}
      >
        <Popover id="popover-contained">
          <Popover.Title as="h3">Popover bottom</Popover.Title>
          <Popover.Content>
            <strong>Holy guacamole!</strong> Check this info.
          </Popover.Content>
        </Popover>
      </Overlay>
  // </div>  
        
   
};

export default CustomAlert;