import React from 'react';

const Blog = ({blogs,handleDelete}) => {
    return (
        <div>
            {
                blogs.map((blog) => (
                    <div className="blog-preview" key={blog.id}>
                        <p>{blog.name} is {blog.age}, He lives in {blog.address}</p>
                        <button onClick={()=> handleDelete(blog.id)}>delete blog</button>
                    </div>
                ))
            }
        </div>
    );
};

export default Blog;