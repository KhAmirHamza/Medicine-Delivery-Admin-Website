import React, { Component } from 'react';
import Home from './components/Home';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom'
import NavBar from './components/Nav';
import Create from './components/Create';
import AddMedicine from './components/AddMedicine';
import ManageMedicine from './components/ManageMedicine';

import Order from './components/Order';
import OrderReceipt from './components/OrderReceipt';
import ManageUser from './components/User/ManageUser';
import ManageRider from './components/Rider/ManageRider';
import ManagePharmacy from './components/Pharmacy/ManagePharmacy';
import AddUpdatePharmacy from './components/Pharmacy/AddUpdate';
import UpdateRider from './components/Rider/Update';
import UpdateUser from './components/User/Update';

class App extends Component {
  tempOrderList = [
    {
      _id: "O5415454152",
      meta_data: {
          created_at: "30 Jan, 2021 06:36 PM",
          status: "Pending",
          total_price: "৳ 500",
          payment_method: "payment_method",
          payment_status: "Cash On Delivery",
          requirement: "requirement",
          user_id: "user_id",
          user_name: "user_name",
          user_phone_number: "user_phone_number",
          deliveryman_id: "deliveryman_id",
          deliveryman_name: "deliveryman_name",
          deliveryman_phone_number: "deliveryman_phone_number",
          pharmacy_id: "pharmacy_id",
          pharmacy_name: "Ma Medical Hall and Pharmacy",
          pharmacy_address: "pharmacy_address",
          pharmacy_phone_number: "pharmacy_phone_number"
      },
      items: [
          {
              medicine_id: "medicine_id",
              features: "features",
              name: "Napa",
              brand: "brand",
              price: "2",
              quantity: "3",
              sub_total: "6"
          },
          {
            medicine_id: "medicine_id",
            features: "features",
            name: "Paracetamol",
            brand: "brand",
            price: "2.5",
            quantity: "7",
            sub_total: "17.5"
        }]
  },
  {
    _id: "O5415454152",
    meta_data: {
        created_at: "30 Jan, 2021 06:36 PM",
        status: "Pending",
        total_price: "৳ 500",
        payment_method: "payment_method",
        payment_status: "Cash On Delivery",
        requirement: "requirement",
        user_id: "user_id",
        user_name: "user_name",
        user_phone_number: "user_phone_number",
        deliveryman_id: "deliveryman_id",
        deliveryman_name: "deliveryman_name",
        deliveryman_phone_number: "deliveryman_phone_number",
        pharmacy_id: "pharmacy_id",
        pharmacy_name: "Ma Medical Hall and Pharmacy",
        pharmacy_address: "pharmacy_address",
        pharmacy_phone_number: "pharmacy_phone_number"
    },
    items: [
        {
            medicine_id: "medicine_id",
            features: "features",
            name: "Napa",
            brand: "brand",
            price: "2",
            quantity: "3",
            sub_total: "6"
        },
        {
          medicine_id: "medicine_id",
          features: "features",
          name: "Paracetamol",
          brand: "brand",
          price: "2.5",
          quantity: "7",
          sub_total: "17.5"
      }]
}

]

  constructor(props) {
    super(props);
    this.state = {
      displyDataList: [],
      cloneDisplayDataList: null
    };
  }



  handleSearch = (searchText) => {
    console.log("handle Search");
    if(searchText && this.state.displyDataList.length>0){
      console.log("searchText");
      console.log(searchText);

      // console.log("cloneDisplayDataList");
      // console.log(this.state.cloneDisplayDataList);
      // console.log("cloneDisplayDataList: ID");
      // console.log(this.state.cloneDisplayDataList);
      console.log(this.state.cloneDisplayDataList[0]._id);
            
    if ( //checking data is available or not
         this.state.cloneDisplayDataList[0].meta_data.name ||
       this.state.cloneDisplayDataList[0]._id)
      {
        console.log("main data is available");
        
        var filteredData = []
        for (let index = 0; index < this.state.cloneDisplayDataList.length; index++) {
          const element = this.state.cloneDisplayDataList[index];
          var rootDataForMatch;
          if (element.meta_data.name) {
            rootDataForMatch = element.meta_data.name;
          }else if(element._id){
            rootDataForMatch = element._id;
          }
           if (rootDataForMatch) {
            console.log("rootDataForMatch");
            console.log(rootDataForMatch);

            if (rootDataForMatch.indexOf(searchText)>-1) {
              filteredData.push(element);
            }

            if (index===(this.state.cloneDisplayDataList.length-1)) {
              this.setState({
                displyDataList: filteredData 
              })
            }
          }
        }
    }

    //console.log("cloneDisplayDataList");
    //console.log(this.state.cloneDisplayDataList);
    }else if (!searchText) {
      this.setState({displyDataList: this.state.cloneDisplayDataList})
      // console.log("displyDataList");
      // console.log(this.state.displyDataList);
    }
  }
  
  handleData = (data) => {
    this.setState({displyDataList: data})
    this.setState({ cloneDisplayDataList: this.state.displyDataList});
   console.log("handleData");
   console.log(this.state.displyDataList.length);
  }

  handleReceipt = ()=>{

  }

  render() {
    return (
      <Router >

        <div style={{display:'flex', flexDirection:'column'}}>
          <div>
          <NavBar handleSearch={this.handleSearch.bind(this)} />

          </div>
         <div style={{marginTop:"60px"}}>
         <Switch>
            <Route exact path="/">
            <ManageMedicine handleData={this.handleData.bind(this)} dataList={this.state.displyDataList}
              handleSearch={this.handleSearch.bind.this}/>
            </Route>
            <Route exact path="/create">
              <Create />
            </Route>

            <Route exact path="/medicine/add" component={AddMedicine}/>

            <Route  path="/medicine">
              <ManageMedicine handleData={this.handleData.bind(this)} dataList={this.state.displyDataList}
              handleSearch={this.handleSearch.bind.this}/>
            </Route>

            <Route exact path="/user/update" component={UpdateUser}/>

            <Route  path="/user">
              <ManageUser />
            </Route>

            <Route exact path="/rider/update" component={UpdateRider}/>
            
            <Route  path="/rider">
              <ManageRider />
            </Route>
            
            <Route exact path="/pharmacy/update" component={AddUpdatePharmacy}/>

            <Route  path="/pharmacy">
              <ManagePharmacy />
            </Route>
            

            <Route exact path="/order">
              <Order handleData={this.handleData.bind(this)} dataList={this.state.displyDataList}/>
            </Route>

            <Route exact path="/order/receipt">

             <OrderReceipt
               handleReceipt={this.handleReceipt.bind(this)}
                orders={this.state.displyDataList}
                from= "FROM" to="to"/>

            </Route>

          </Switch>
         </div>
        </div>
      </Router>
    );
  }
}

export default App;